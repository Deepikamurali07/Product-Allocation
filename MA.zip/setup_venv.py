import os
import subprocess
import sys

def create_virtual_environment(venv_name="venv"):
    # Create the virtual environment
    subprocess.check_call([sys.executable, '-m', 'venv', venv_name])

def activate_virtual_environment(venv_name="venv"):
    # Activate the virtual environment based on the OS
    if os.name == 'nt':
        # Windows
        activate_script = os.path.join(venv_name, 'Scripts', 'activate')
    else:
        # Unix or MacOS
        activate_script = os.path.join(venv_name, 'bin', 'activate')
    
    return activate_script

def install_requirements(venv_name="venv", requirements_file="requirements.txt"):
    # Install the required libraries from requirements.txt
    pip_executable = os.path.join(venv_name, 'bin', 'pip') if os.name != 'nt' else os.path.join(venv_name, 'Scripts', 'pip')
    subprocess.check_call([pip_executable, 'install', '-r', requirements_file])

def main():
    venv_name = "venv"
    requirements_file = "requirements.txt"
    
    # Step 1: Create virtual environment
    create_virtual_environment(venv_name)
    
    # Step 2: Activate virtual environment (this is only for display, activation is usually done in the shell)
    activate_script = activate_virtual_environment(venv_name)
    print(f"To activate the virtual environment, run:\nsource {activate_script}" if os.name != 'nt' else f"{activate_script}.bat")
    
    # Step 3: Install required libraries
    install_requirements(venv_name, requirements_file)
    print("Required libraries have been installed.")

if __name__ == "__main__":
    main()
